//alert("halo semua")
console.log("Selamat pagi");

//variable

//let var const

//let lebih kepake drpd var sekarang
let nama = "Zakky";
let umur = 20;

//var kuno, bisa double variable sama
var nama2 = "Zakky";

console.log(nama);
console.log(umur);

//variable tidak dapat berubah
const nama3= "Suherman";
nama3= "budi";
console.log(nama3);

//tipe data
//Primitif

//string

let komputer = "Lenovo";

//number

let luas = 100;

//boolean

let aktif = true;
let mati = false;

//undefined

let unand;
console.log(unand);

//null

let nomor_hp = null;

//tipe data non primitif

//object

let mahasiswa = {
    nama: "Zakky",
    nim: "2311522018",
    umur: 21,
    email: "zakkyaulialdrin@gmail.com",
    alamat:{
        jalan: "Jl. Jawa gadut",
        kelurahan: "Marpoyan Damai"
    }
}

console.log(mahasiswa);
console.log(mahasiswa['umur']);
console.log(`Umur Mahasiswa dengan nama ${mahasiswa['nama']} adalah ${mahasiswa['umur']}`);

//array

let buah = ['apel', 'mangga', 'manggis']

let campuran = [1, 'rumah', 'kantor', 3.15, true]
console.log(campuran)
console.log(buah)
console.log(buah[0]);
console.log(buah.length);


//type correction
let a = 10
let b = "5"
console.log(a+b);
console.log(a-b);

let c = 5;
let d= 10

//aritmatika
console.log(a+b);
console.log(a-b);
console.log(a*b);
console.log(a/b);
console.log(a % b);
console.log(a ** b);

//increment
let e= 3
let newe = ++e
console.log(newe);

//decreement
console.log(--d);

//operator perbandingan

console.log( "5" == 5);
console.log( "5" === 5);
console.log( "5" !== 5);
console.log( "5" != 5);

console.log( 7 <= 5);
console.log( 4 <= 5);

//operator logika

console.log ("Operator logika and", true && false);
console.log ("Operator logika and", true && true);
console.log ("Operator logika or", true || true);
console.log ("Operator logika and", true || false);

console.log ("Operator logika and", false || false);

//ternary operator

//let buah;
const ternary = 1 === '2'? truebuah : false;
console.log(ternary)

//struktur control

//percabangan if
let ukuran = 5;

if(ukuran > 10){
    console.log('ukuran ini kebesaran');
} else{
    console.log('ukuran ini kekecilan')
}

//perulangan

//for

//while

//do while

//function

function greeting(nama){
    return `halo selamat pagi ${nama}`
}

console.log(greeting('asep'))

const arrow= (nama) =>{
    return `halo selamat pagi ${nama}`
}

console.log(arrow('budi'))